

module.exports =  function(details){

    module.inviteUser = {
        title   : `A sua credential está pronta`,
        subject : `WalliD: Recebeu uma nova credencial  ${details.template} emitida por ${details.ca}`
    },
    module.sendEmailApprove = {
        subject : `WalliD: A sua credencial ${details.template} foi aprovada`
    },
    module.pendingAprovals = {
        subject : `WalliD: Tem credenciais à espera da sua aprovação na plataforma WalliD.`
    },
    module.credentialRevoke = {
        subject : `WalliD: A sua credencial ${details.template} da ${details.ca} foi revogada`
    }
    return module;
}