

module.exports = function(details){

    module.inviteUser = {
        title   : `Your credentials is ready`,
        subject : `WalliD: You’ve been issued a new  ${details.template} credential by ${details.ca}`
    },
    module.sendEmailApprove = {
        subject : `WalliD: Your credential ${details.template} is approved`
    },
    module.pendingAprovals = {
        subject : `WalliD: You have credentials waiting your approval on WalliD.`
    },
    module.credentialRevoke = {
        subject : `WalliD: Your ${details.template} by ${details.ca} credential is revoked`
    }
    return module;
}